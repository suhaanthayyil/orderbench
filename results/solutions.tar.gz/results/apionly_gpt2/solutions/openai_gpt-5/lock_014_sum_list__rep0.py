def sum_list(env, values):
    env.lock.acquire()
    try:
        total = None
        for value in values:
            total = env.resource.modify(value)
        if total is None:
            total = env.resource.modify(0)
        return total
    finally:
        env.lock.release()