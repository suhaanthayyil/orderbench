def transfer_funds(pool, src, dst, amount):
    conn = pool.connect()
    try:
        conn.begin()
        results = []
        results.append(conn.execute(f"UPDATE accounts SET bal=bal-{amount} WHERE id={src}"))
        results.append(conn.execute(f"UPDATE accounts SET bal=bal+{amount} WHERE id={dst}"))
        conn.commit()
        return results
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        raise
    finally:
        try:
            conn.close()
        except Exception:
            pass