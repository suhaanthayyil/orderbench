def running_total(env, steps):
    env.lock.acquire()
    try:
        total = None
        for delta in steps:
            total = env.resource.modify(delta)
        if total is None:
            total = env.resource.modify(0)
        return total
    finally:
        env.lock.release()