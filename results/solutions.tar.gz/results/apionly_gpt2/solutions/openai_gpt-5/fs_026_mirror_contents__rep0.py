def mirror_contents(fs, path):
    handle = fs.open(path)
    primary_exc = None
    try:
        contents = handle.read()
        handle.write(contents)
        return contents
    except BaseException as e:
        primary_exc = e
        raise
    finally:
        try:
            handle.close()
        except Exception:
            if primary_exc is None:
                raise