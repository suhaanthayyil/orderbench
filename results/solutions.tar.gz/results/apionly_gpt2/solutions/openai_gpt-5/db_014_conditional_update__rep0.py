def conditional_update(pool, table, assignment, where):
    conn = pool.connect()
    try:
        conn.begin()
        try:
            result = conn.execute(f"UPDATE {table} SET {assignment} WHERE {where}")
            conn.commit()
            return result
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
    finally:
        conn.close()