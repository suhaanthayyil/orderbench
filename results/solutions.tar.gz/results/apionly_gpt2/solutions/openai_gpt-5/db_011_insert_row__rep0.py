def insert_row(pool, table, value):
    conn = pool.connect()
    try:
        conn.begin()
        try:
            sql = f"INSERT INTO {table} VALUES ({value})"
            result = conn.execute(sql)
            conn.commit()
            return result
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
    finally:
        conn.close()