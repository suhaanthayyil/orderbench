def run_query2(pool, sql_a, sql_b):
    conn = None
    began = False
    try:
        conn = pool.connect()
        conn.begin()
        began = True
        conn.execute(sql_a)
        result_b = conn.execute(sql_b)
        conn.commit()
        return result_b
    except Exception:
        try:
            if began and conn is not None:
                conn.rollback()
        except Exception:
            pass
        raise
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass