def idempotent_write(pool, key, value):
    conn = pool.connect()
    try:
        conn.begin()
        sql = f"INSERT INTO kv(k,v) VALUES('{key}','{value}') ON CONFLICT(k) DO UPDATE SET v='{value}'"
        result = conn.execute(sql)
        conn.commit()
        return result
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        raise
    finally:
        conn.close()