def append_audit(pool, event):
    conn = pool.connect()
    try:
        conn.begin()
        try:
            result = conn.execute(f"INSERT INTO audit VALUES ({event})")
            conn.commit()
            return result
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
    finally:
        conn.close()