def transfer_between(env, amount):
    env.lock.acquire()
    try:
        env.resource.modify(-amount)
        final = env.resource.modify(amount)
        return final
    finally:
        env.lock.release()