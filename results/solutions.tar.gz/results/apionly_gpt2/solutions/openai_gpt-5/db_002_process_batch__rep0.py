def process_batch(pool, statements):
    conn = pool.connect()
    results = []
    began = False
    committed = False
    try:
        conn.begin()
        began = True
        for sql in statements:
            results.append(conn.execute(sql))
        conn.commit()
        committed = True
        return results
    except Exception:
        try:
            if began and not committed:
                conn.rollback()
        except Exception:
            pass
        raise
    finally:
        try:
            conn.close()
        except Exception:
            pass