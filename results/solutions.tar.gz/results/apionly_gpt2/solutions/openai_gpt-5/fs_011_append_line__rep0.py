def append_line(fs, path, line):
    handle = fs.open(path)
    try:
        contents = handle.read()
        handle.write(contents + "\n" + line)
        return "appended"
    finally:
        try:
            handle.close()
        except Exception:
            pass