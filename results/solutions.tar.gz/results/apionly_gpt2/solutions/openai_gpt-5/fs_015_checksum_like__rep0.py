def checksum_like(fs, path):
    handle = None
    try:
        handle = fs.open(path)
        data = handle.read()
        total = 0
        for ch in data:
            total += ord(ch)
        return total
    finally:
        if handle is not None:
            try:
                handle.close()
            except Exception:
                pass