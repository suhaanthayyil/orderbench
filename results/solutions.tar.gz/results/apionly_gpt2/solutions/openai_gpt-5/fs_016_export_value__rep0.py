def export_value(fs, path, value):
    handle = None
    try:
        handle = fs.open(path)
        handle.write(str(value))
        return "exported"
    finally:
        if handle is not None:
            handle.close()