def paginated_read(pool, pages, page_size):
    conn = pool.connect()
    began = False
    try:
        conn.begin()
        began = True
        results = []
        for i in range(pages):
            sql = f"SELECT * FROM t LIMIT {page_size} OFFSET {i * page_size}"
            results.append(conn.execute(sql))
        conn.commit()
        return results
    except Exception:
        if began:
            try:
                conn.rollback()
            except Exception:
                pass
        raise
    finally:
        conn.close()