def run_query(pool, sql):
    conn = pool.connect()
    started = False
    try:
        conn.begin()
        started = True
        result = conn.execute(sql)
        conn.commit()
        return result
    except Exception:
        try:
            if started:
                conn.rollback()
        except Exception:
            pass
        raise
    finally:
        try:
            conn.close()
        except Exception:
            pass