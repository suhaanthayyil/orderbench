def bulk_insert(pool, rows):
    conn = pool.connect()
    try:
        conn.begin()
        results = []
        try:
            for row in rows:
                results.append(conn.execute(f"INSERT INTO t VALUES ({row})"))
            conn.commit()
            return results
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
    finally:
        conn.close()