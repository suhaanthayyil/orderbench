def serialize_obj(fs, path, name, count):
    data = f"{name}:{count}"
    handle = fs.open(path)
    try:
        handle.write(data)
    finally:
        handle.close()
    return data