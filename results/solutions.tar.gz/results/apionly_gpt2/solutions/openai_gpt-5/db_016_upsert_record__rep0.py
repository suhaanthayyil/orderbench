def upsert_record(pool, table, key, value):
    conn = pool.connect()
    try:
        conn.begin()
        try:
            sql = f"UPSERT INTO {table} KEY {key} VALUE {value}"
            result = conn.execute(sql)
            conn.commit()
            return result
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
    finally:
        conn.close()