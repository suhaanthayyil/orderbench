def parse_header(fs, path):
    handle = fs.open(path)
    try:
        data = handle.read()
    finally:
        handle.close()
    newline_index = data.find('\n')
    return data if newline_index == -1 else data[:newline_index]