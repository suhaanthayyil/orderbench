def delete_rows(pool, table, where):
    conn = pool.connect()
    try:
        conn.begin()
        try:
            result = conn.execute(f"DELETE FROM {table} WHERE {where}")
            conn.commit()
            return result
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
    finally:
        try:
            conn.close()
        except Exception:
            pass