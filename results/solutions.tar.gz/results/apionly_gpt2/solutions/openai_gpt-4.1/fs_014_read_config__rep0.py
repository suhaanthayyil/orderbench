def read_config(fs, path):
    handle = fs.open(path)
    try:
        content = handle.read()
        return "config:" + content
    finally:
        handle.close()