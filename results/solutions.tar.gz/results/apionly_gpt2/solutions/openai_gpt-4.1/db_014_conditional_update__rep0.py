def conditional_update(pool, table, assignment, where):
    conn = pool.connect()
    try:
        conn.begin()
        sql = f"UPDATE {table} SET {assignment} WHERE {where}"
        result = conn.execute(sql)
        conn.commit()
        return result
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()