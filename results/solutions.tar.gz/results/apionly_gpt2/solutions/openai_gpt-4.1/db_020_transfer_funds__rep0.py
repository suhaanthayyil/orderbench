def transfer_funds(pool, src, dst, amount):
    conn = pool.connect()
    try:
        conn.begin()
        res1 = conn.execute(f"UPDATE accounts SET bal=bal-{amount} WHERE id={src}")
        res2 = conn.execute(f"UPDATE accounts SET bal=bal+{amount} WHERE id={dst}")
        conn.commit()
        return [res1, res2]
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()