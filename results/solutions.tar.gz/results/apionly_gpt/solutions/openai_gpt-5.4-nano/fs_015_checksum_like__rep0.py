def checksum_like(fs, path):
    handle = fs.open(path)
    try:
        data = handle.read()
        return sum(ord(ch) for ch in data)
    finally:
        handle.close()