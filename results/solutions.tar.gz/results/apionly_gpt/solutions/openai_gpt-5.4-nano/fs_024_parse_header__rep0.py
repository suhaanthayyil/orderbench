def parse_header(fs, path):
    handle = fs.open(path)
    try:
        data = handle.read()
        newline_index = data.find("\n")
        return data if newline_index == -1 else data[:newline_index]
    finally:
        handle.close()