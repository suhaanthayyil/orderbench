def bounded_add(env, amount):
    env.lock.acquire()
    try:
        new_value = env.resource.modify(amount)
        return new_value
    finally:
        env.lock.release()