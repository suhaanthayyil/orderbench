def count_rows(pool, table):
    conn = pool.connect()
    try:
        conn.begin()
        result = conn.execute(f"SELECT COUNT(*) FROM {table}")
        conn.commit()
        return result
    except Exception:
        try:
            conn.rollback()
        finally:
            conn.close()
        raise
    finally:
        try:
            conn.close()
        except Exception:
            pass