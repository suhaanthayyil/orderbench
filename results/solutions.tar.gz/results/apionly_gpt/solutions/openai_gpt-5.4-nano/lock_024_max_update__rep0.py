def max_update(env, current, target):
    env.lock.acquire()
    try:
        gap = target - current
        delta = gap if gap > 0 else 0
        return env.resource.modify(delta)
    finally:
        env.lock.release()