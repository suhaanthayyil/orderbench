def uppercase_file(fs, path):
    handle = fs.open(path)
    try:
        original = handle.read()
    finally:
        handle.close()
    handle = fs.open(path)
    try:
        handle.write(original.upper())
    finally:
        handle.close()
    return original