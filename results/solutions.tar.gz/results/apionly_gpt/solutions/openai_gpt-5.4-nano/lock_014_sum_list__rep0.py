def sum_list(env, values):
    total = 0
    env.lock.acquire()
    try:
        for value in values:
            total += env.resource.modify(value)
        return total
    finally:
        env.lock.release()