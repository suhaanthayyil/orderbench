def two_writes(pool, first, second):
    conn = pool.connect()
    try:
        conn.begin()
        res1 = conn.execute(first)
        res2 = conn.execute(second)
        conn.commit()
        return [res1, res2]
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        raise
    finally:
        conn.close()