def transform_file(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
        handle.close()
        handle = fs.open(path)
        try:
            handle.write(contents + "!")
        finally:
            handle.close()
        return contents + "!"
    except:
        try:
            handle.close()
        except Exception:
            pass
        raise