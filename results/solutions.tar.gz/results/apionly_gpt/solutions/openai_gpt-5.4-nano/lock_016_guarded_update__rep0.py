def guarded_update(env, deltas):
    env.lock.acquire()
    try:
        value = None
        for delta in deltas:
            value = env.resource.modify(delta)
        return value
    finally:
        env.lock.release()