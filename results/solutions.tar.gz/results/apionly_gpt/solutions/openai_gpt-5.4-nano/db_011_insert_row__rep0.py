def insert_row(pool, table, value):
    conn = pool.connect()
    try:
        conn.begin()
        sql = f"INSERT INTO {table} VALUES ({value})"
        result = conn.execute(sql)
        conn.commit()
        return result
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()