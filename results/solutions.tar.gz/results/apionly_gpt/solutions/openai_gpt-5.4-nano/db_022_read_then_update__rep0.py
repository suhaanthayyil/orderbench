def read_then_update(pool, row_id, new_value):
    conn = pool.connect()
    try:
        conn.begin()
        conn.execute(f"SELECT v FROM t WHERE id={row_id}")
        update_result = conn.execute(
            f"UPDATE t SET v={new_value} WHERE id={row_id}"
        )
        conn.commit()
        return update_result
    except Exception:
        try:
            conn.rollback()
        finally:
            conn.close()
        raise
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass