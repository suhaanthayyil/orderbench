def parse_header(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
        return contents.split('\n', 1)[0]
    finally:
        handle.close()