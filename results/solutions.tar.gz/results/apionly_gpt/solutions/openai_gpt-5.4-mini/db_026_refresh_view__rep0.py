def refresh_view(pool, view):
    conn = pool.connect()
    try:
        conn.begin()
        try:
            result = conn.execute(f"REFRESH MATERIALIZED VIEW {view}")
            conn.commit()
            return result
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
    finally:
        conn.close()