def count_rows(pool, table):
    conn = pool.connect()
    try:
        conn.begin()
        result = conn.execute(f"SELECT COUNT(*) FROM {table}")
        conn.commit()
        return result
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        raise
    finally:
        conn.close()