def process_batch(pool, statements):
    conn = pool.connect()
    begun = False
    try:
        try:
            conn.begin()
            begun = True
            results = []
            for sql in statements:
                results.append(conn.execute(sql))
            conn.commit()
            begun = False
            return results
        finally:
            if begun:
                try:
                    conn.rollback()
                finally:
                    conn.close()
            else:
                conn.close()
    except:
        raise