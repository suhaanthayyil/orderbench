def conditional_update(pool, table, assignment, where):
    conn = pool.connect()
    try:
        conn.begin()
        try:
            result = conn.execute(f"UPDATE {table} SET {assignment} WHERE {where}")
            conn.commit()
            return result
        except Exception:
            conn.rollback()
            raise
    finally:
        conn.close()