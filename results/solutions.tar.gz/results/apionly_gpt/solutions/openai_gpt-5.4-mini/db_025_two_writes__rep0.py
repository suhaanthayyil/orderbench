def two_writes(pool, first, second):
    conn = pool.connect()
    try:
        conn.begin()
        try:
            r1 = conn.execute(first)
            r2 = conn.execute(second)
            conn.commit()
            return [r1, r2]
        except Exception:
            conn.rollback()
            raise
    finally:
        conn.close()