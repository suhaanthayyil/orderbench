def running_total(env, steps):
    env.lock.acquire()
    try:
        total = None
        for value in steps:
            total = env.resource.modify(value)
        return total
    finally:
        env.lock.release()