def checksum_like(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
        return sum(ord(ch) for ch in contents)
    finally:
        handle.close()