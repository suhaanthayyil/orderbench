def paginated_read(pool, pages, page_size):
    conn = None
    try:
        conn = pool.connect()
        conn.begin()
        results = []
        for i in range(pages):
            sql = f"SELECT * FROM t LIMIT {page_size} OFFSET {i * page_size}"
            results.append(conn.execute(sql))
        conn.commit()
        return results
    except Exception:
        if conn is not None:
            try:
                conn.rollback()
            except Exception:
                pass
        raise
    finally:
        if conn is not None:
            conn.close()