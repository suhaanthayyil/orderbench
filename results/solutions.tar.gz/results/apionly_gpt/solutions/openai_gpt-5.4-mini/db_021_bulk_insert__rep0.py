def bulk_insert(pool, rows):
    conn = None
    begun = False
    try:
        conn = pool.connect()
        conn.begin()
        begun = True
        results = []
        for row in rows:
            results.append(conn.execute(f"INSERT INTO t VALUES ({row})"))
        conn.commit()
        return results
    except Exception:
        if conn is not None and begun:
            try:
                conn.rollback()
            except Exception:
                pass
        raise
    finally:
        if conn is not None:
            conn.close()