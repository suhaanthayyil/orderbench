def insert_row(pool, table, value):
    conn = pool.connect()
    try:
        conn.begin()
        result = conn.execute(f"INSERT INTO {table} VALUES ({value})")
        conn.commit()
        return result
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        raise
    finally:
        conn.close()