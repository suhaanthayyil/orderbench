def upsert_record(pool, table, key, value):
    conn = pool.connect()
    try:
        conn.begin()
        try:
            result = conn.execute(f"UPSERT INTO {table} KEY {key} VALUE {value}")
            conn.commit()
            return result
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
    finally:
        conn.close()