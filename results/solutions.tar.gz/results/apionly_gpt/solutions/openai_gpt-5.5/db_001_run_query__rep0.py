def run_query(pool, sql):
    conn = pool.connect()
    begun = False
    committed = False
    try:
        conn.begin()
        begun = True
        result = conn.execute(sql)
        conn.commit()
        committed = True
        return result
    except Exception:
        if begun and not committed:
            conn.rollback()
        raise
    finally:
        conn.close()