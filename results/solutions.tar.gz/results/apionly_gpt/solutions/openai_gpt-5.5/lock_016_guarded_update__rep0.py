def guarded_update(env, deltas):
    env.lock.acquire()
    try:
        final_value = None
        for delta in deltas:
            final_value = env.resource.modify(delta)
        return final_value
    finally:
        env.lock.release()