def serialize_obj(fs, path, name, count):
    data = name + ":" + str(count)
    handle = fs.open(path)
    try:
        handle.write(data)
        return data
    finally:
        handle.close()