def transform_file(fs, path):
    handle = fs.open(path)
    try:
        transformed = handle.read() + "!"
        handle.write(transformed)
        return transformed
    finally:
        handle.close()