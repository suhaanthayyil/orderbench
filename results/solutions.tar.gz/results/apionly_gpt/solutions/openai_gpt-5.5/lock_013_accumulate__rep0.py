def accumulate(env, step, times):
    env.lock.acquire()
    try:
        final_value = None
        for _ in range(times):
            final_value = env.resource.modify(step)
        return final_value
    finally:
        env.lock.release()