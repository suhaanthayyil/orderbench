def batch_apply(env, batch):
    env.lock.acquire()
    try:
        final_value = None
        for delta in batch:
            final_value = env.resource.modify(delta)
        return final_value
    finally:
        env.lock.release()