def count_rows(pool, table):
    conn = pool.connect()
    began = False
    try:
        conn.begin()
        began = True
        result = conn.execute(f"SELECT COUNT(*) FROM {table}")
        conn.commit()
        return result
    except Exception:
        if began:
            try:
                conn.rollback()
            except Exception:
                pass
        raise
    finally:
        conn.close()