def two_writes(pool, first, second):
    conn = pool.connect()
    try:
        conn.begin()
        try:
            results = [conn.execute(first), conn.execute(second)]
            conn.commit()
            return results
        except Exception:
            conn.rollback()
            raise
    finally:
        conn.close()