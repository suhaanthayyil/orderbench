def process_batch(pool, statements):
    conn = pool.connect()
    try:
        conn.begin()
        results = []
        try:
            for sql in statements:
                results.append(conn.execute(sql))
            conn.commit()
            return results
        except Exception:
            conn.rollback()
            raise
    finally:
        conn.close()