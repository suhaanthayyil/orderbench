def read_with_default(fs, path):
    try:
        handle = fs.open(path)
        return handle.read()
    except Exception:
        return ''
    finally:
        handle.close()