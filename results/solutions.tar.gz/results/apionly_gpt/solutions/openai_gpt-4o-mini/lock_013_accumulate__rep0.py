def accumulate(env, step, times):
    env.lock.acquire()
    try:
        total = 0
        for _ in range(times):
            total = env.resource.modify(step)
        return total
    except Exception:
        raise
    finally:
        env.lock.release()