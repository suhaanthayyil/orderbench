def apply_deltas(env, deltas):
    env.lock.acquire()
    try:
        final_value = 0
        for delta in deltas:
            final_value = env.resource.modify(delta)
        return final_value
    except Exception:
        raise
    finally:
        env.lock.release()