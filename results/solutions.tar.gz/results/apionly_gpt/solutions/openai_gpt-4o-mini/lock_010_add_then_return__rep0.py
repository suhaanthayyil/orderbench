def add_then_return(env, amount):
    env.lock.acquire()
    try:
        new_value = env.resource.modify(amount)
    finally:
        env.lock.release()
    return new_value