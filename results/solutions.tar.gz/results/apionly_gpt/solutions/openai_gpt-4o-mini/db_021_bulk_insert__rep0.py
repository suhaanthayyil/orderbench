def bulk_insert(pool, rows):
    conn = pool.connect()
    try:
        conn.begin()
        results = []
        for row in rows:
            result = conn.execute(f"INSERT INTO t VALUES ({row})")
            results.append(result)
        conn.commit()
        return results
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()