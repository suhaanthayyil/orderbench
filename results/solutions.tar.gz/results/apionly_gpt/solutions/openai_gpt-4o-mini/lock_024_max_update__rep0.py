def max_update(env, current, target):
    env.lock.acquire()
    try:
        gap = target - current
        result = env.resource.modify(gap if gap > 0 else 0)
    finally:
        env.lock.release()
    return result