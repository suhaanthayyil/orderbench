def bounded_add(env, amount):
    env.lock.acquire()
    try:
        new_value = env.resource.modify(amount)
    finally:
        env.lock.release()
    return new_value