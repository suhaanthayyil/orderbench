def process_batch(pool, statements):
    conn = pool.connect()
    results = []
    try:
        conn.begin()
        for statement in statements:
            result = conn.execute(statement)
            results.append(result)
        conn.commit()
        return results
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()