def guarded_update(env, deltas):
    env.lock.acquire()
    try:
        final_value = env.resource.modify(deltas[0])  # Initialize with the first delta
        for delta in deltas[1:]:
            final_value = env.resource.modify(delta)
        return final_value
    except Exception:
        raise  # Re-raise the exception
    finally:
        env.lock.release()