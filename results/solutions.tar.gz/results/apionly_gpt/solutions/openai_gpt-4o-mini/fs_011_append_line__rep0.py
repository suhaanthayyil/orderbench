def append_line(fs, path, line):
    handle = fs.open(path)
    try:
        current_contents = handle.read()
        handle.write(current_contents + '\n' + line)
    finally:
        handle.close()
    return "appended"