def transfer_funds(pool, src, dst, amount):
    conn = pool.connect()
    try:
        conn.begin()
        debit_result = conn.execute(f"UPDATE accounts SET bal=bal-{amount} WHERE id={src}")
        credit_result = conn.execute(f"UPDATE accounts SET bal=bal+{amount} WHERE id={dst}")
        conn.commit()
        return [debit_result, credit_result]
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()