def parse_header(fs, path):
    handle = fs.open(path)
    try:
        content = handle.read()
        return content.splitlines()[0]
    finally:
        handle.close()