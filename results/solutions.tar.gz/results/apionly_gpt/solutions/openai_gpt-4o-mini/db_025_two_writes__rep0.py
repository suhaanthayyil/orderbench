def two_writes(pool, first, second):
    conn = pool.connect()
    try:
        conn.begin()
        result1 = conn.execute(first)
        result2 = conn.execute(second)
        conn.commit()
        return [result1, result2]
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()