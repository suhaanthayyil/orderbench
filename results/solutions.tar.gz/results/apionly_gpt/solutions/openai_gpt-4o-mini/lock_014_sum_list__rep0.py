def sum_list(env, values):
    env.lock.acquire()
    try:
        total = 0
        for value in values:
            total += env.resource.modify(value)
        return total
    except Exception as e:
        raise e  # Ensure balance of acquire/release
    finally:
        env.lock.release()