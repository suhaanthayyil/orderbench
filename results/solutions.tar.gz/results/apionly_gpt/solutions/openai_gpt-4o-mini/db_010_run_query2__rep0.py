def run_query2(pool, sql_a, sql_b):
    conn = pool.connect()
    try:
        conn.begin()
        result_a = conn.execute(sql_a)
        result_b = conn.execute(sql_b)
        conn.commit()
        return result_b
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()