def reset_then_add(env, current, amount):
    env.lock.acquire()
    try:
        env.resource.modify(-current)
        final_value = env.resource.modify(amount)
    except Exception:
        env.lock.release()
        raise
    env.lock.release()
    return final_value