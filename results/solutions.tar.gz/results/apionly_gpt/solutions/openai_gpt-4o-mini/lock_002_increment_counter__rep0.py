def increment_counter(env, n):
    env.lock.acquire()
    try:
        new_value = env.resource.modify(n)
    except Exception:
        env.lock.release()
        raise
    env.lock.release()
    return new_value