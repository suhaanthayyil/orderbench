def delete_rows(pool, table, where):
    conn = pool.connect()
    try:
        conn.begin()
        sql = f"DELETE FROM {table} WHERE {where}"
        result = conn.execute(sql)
        conn.commit()
        return result
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()