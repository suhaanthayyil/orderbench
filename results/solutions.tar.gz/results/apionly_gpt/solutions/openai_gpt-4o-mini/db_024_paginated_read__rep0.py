def paginated_read(pool, pages, page_size):
    conn = pool.connect()
    try:
        conn.begin()
        results = []
        for i in range(pages):
            sql = f"SELECT * FROM t LIMIT {page_size} OFFSET {i * page_size}"
            results.append(conn.execute(sql))
        conn.commit()
        return results
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()