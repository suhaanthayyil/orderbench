def uppercase_file(fs, path):
    handle = fs.open(path)
    try:
        original_contents = handle.read()
        uppercased_contents = original_contents.upper()
        handle.write(uppercased_contents)
        return original_contents
    finally:
        handle.close()