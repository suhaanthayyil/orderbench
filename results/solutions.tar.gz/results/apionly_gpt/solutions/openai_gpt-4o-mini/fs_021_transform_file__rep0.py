def transform_file(fs, path):
    handle = fs.open(path)
    try:
        content = handle.read()
        transformed_content = content + "!"
        handle.write(transformed_content)
        return transformed_content
    finally:
        handle.close()