def batch_apply(env, batch):
    env.lock.acquire()
    try:
        final_value = 0
        for delta in batch:
            final_value = env.resource.modify(delta)
        return final_value
    except Exception:
        raise
    finally:
        env.lock.release()