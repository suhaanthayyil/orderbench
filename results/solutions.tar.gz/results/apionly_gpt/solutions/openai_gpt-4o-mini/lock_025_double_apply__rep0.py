def double_apply(env, delta):
    env.lock.acquire()
    try:
        value = env.resource.modify(delta)
        value = env.resource.modify(delta)
    finally:
        env.lock.release()
    return value