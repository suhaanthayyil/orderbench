def serialize_obj(fs, path, name, count):
    handle = fs.open(path)
    try:
        data = f"{name}:{count}"
        handle.write(data)
        return data
    finally:
        handle.close()