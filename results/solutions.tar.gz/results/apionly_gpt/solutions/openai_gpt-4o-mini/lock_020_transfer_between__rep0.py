def transfer_between(env, amount):
    env.lock.acquire()
    try:
        env.resource.modify(-amount)
        final_value = env.resource.modify(amount)
    except Exception:
        env.lock.release()  # Ensure lock is released in case of an exception
        raise  # Re-raise the exception to handle it externally
    env.lock.release()
    return final_value