def decrement(env, n):
    env.lock.acquire()
    try:
        new_value = env.resource.modify(-n)
    finally:
        env.lock.release()
    return new_value