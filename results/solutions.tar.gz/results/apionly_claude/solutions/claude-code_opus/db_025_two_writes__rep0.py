def two_writes(pool, first, second):
    conn = pool.connect()
    try:
        conn.begin()
        try:
            results = [conn.execute(first), conn.execute(second)]
            conn.commit()
            return results
        except:
            conn.rollback()
            raise
    finally:
        conn.close()