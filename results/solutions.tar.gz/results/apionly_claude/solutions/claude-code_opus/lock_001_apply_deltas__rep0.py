def apply_deltas(env, deltas):
    env.lock.acquire()
    try:
        result = None
        for delta in deltas:
            result = env.resource.modify(delta)
        return result
    finally:
        env.lock.release()