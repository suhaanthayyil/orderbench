def count_chars(fs, path):
    handle = fs.open(path)
    try:
        return len(handle.read())
    finally:
        handle.close()