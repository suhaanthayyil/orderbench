def serialize_obj(fs, path, name, count):
    handle = fs.open(path)
    try:
        serialized = name + ":" + str(count)
        handle.write(serialized)
        return serialized
    finally:
        handle.close()