def parse_header(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
    finally:
        handle.close()
    return contents.split("\n", 1)[0]