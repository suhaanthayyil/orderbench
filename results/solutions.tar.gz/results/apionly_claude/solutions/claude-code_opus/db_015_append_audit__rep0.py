def append_audit(pool, event):
    conn = pool.connect()
    try:
        conn.begin()
        result = conn.execute("INSERT INTO audit VALUES ({})".format(event))
        conn.commit()
        return result
    finally:
        conn.close()