def read_config(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
    finally:
        handle.close()
    return "config:" + contents