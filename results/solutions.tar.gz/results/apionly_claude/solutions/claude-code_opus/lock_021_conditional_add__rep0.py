def conditional_add(env, delta, enabled):
    env.lock.acquire()
    try:
        return env.resource.modify(delta if enabled else 0)
    finally:
        env.lock.release()