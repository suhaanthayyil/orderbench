def read_with_default(fs, path):
    handle = fs.open(path)
    try:
        return handle.read()
    finally:
        handle.close()