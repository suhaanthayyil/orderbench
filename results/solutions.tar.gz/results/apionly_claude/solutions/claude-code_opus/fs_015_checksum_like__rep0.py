def checksum_like(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
    finally:
        handle.close()
    return sum(ord(c) for c in contents)