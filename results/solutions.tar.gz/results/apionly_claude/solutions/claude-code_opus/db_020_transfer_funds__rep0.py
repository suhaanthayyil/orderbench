def transfer_funds(pool, src, dst, amount):
    conn = pool.connect()
    try:
        conn.begin()
        r1 = conn.execute(f"UPDATE accounts SET bal=bal-{amount} WHERE id={src}")
        r2 = conn.execute(f"UPDATE accounts SET bal=bal+{amount} WHERE id={dst}")
        conn.commit()
        return [r1, r2]
    except BaseException:
        conn.rollback()
        raise
    finally:
        conn.close()