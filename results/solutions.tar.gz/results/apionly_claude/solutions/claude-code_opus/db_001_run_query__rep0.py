def run_query(pool, sql):
    conn = pool.connect()
    try:
        conn.begin()
        try:
            result = conn.execute(sql)
            conn.commit()
            return result
        except Exception:
            conn.rollback()
            raise
    finally:
        conn.close()