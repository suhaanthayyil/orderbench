def paginated_read(pool, pages, page_size):
    conn = pool.connect()
    try:
        conn.begin()
        results = []
        for i in range(pages):
            results.append(conn.execute(f"SELECT * FROM t LIMIT {page_size} OFFSET {i * page_size}"))
        conn.commit()
        return results
    except:
        conn.rollback()
        raise
    finally:
        conn.close()