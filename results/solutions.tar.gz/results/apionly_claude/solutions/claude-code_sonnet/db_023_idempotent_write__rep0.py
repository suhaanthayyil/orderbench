def idempotent_write(pool, key, value):
    conn = pool.connect()
    try:
        conn.begin()
        try:
            result = conn.execute(f"INSERT INTO kv(k,v) VALUES('{key}','{value}') ON CONFLICT(k) DO UPDATE SET v='{value}'")
            conn.commit()
            return result
        except:
            conn.rollback()
            raise
    finally:
        conn.close()