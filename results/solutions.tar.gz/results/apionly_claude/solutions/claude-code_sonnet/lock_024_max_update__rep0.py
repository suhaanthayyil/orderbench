def max_update(env, current, target):
    env.lock.acquire()
    try:
        gap = target - current
        if gap > 0:
            result = env.resource.modify(gap)
        else:
            result = env.resource.modify(0)
    finally:
        env.lock.release()
    return result