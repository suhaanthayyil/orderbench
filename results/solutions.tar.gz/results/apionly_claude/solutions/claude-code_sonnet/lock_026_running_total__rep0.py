def running_total(env, steps):
    env.lock.acquire()
    try:
        result = 0
        for value in steps:
            result = env.resource.modify(value)
        return result
    finally:
        env.lock.release()