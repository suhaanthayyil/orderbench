def parse_header(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
    finally:
        handle.close()
    newline_pos = contents.find('\n')
    if newline_pos == -1:
        return contents
    return contents[:newline_pos]