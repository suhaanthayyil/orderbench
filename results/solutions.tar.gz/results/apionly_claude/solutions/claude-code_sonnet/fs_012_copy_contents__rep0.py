def copy_contents(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
        handle.write(contents)
    finally:
        handle.close()
    return contents