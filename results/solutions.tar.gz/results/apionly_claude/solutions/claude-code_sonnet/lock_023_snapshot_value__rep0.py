def snapshot_value(env, start):
    env.lock.acquire()
    try:
        value = env.resource.modify(0)
    finally:
        env.lock.release()
    return value