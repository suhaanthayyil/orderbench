def uppercase_file(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
        handle.write(contents.upper())
    finally:
        handle.close()
    return contents