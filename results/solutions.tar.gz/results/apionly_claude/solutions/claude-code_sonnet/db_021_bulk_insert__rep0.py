def bulk_insert(pool, rows):
    conn = pool.connect()
    try:
        conn.begin()
        try:
            results = [conn.execute(f"INSERT INTO t VALUES ({row})") for row in rows]
            conn.commit()
            return results
        except:
            conn.rollback()
            raise
    finally:
        conn.close()