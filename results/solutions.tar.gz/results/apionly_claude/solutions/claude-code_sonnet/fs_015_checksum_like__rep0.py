def checksum_like(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
        return sum(ord(c) for c in contents)
    finally:
        handle.close()