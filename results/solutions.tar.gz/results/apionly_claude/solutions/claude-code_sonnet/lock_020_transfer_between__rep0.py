def transfer_between(env, amount):
    env.lock.acquire()
    try:
        env.resource.modify(-amount)
        result = env.resource.modify(amount)
    finally:
        env.lock.release()
    return result