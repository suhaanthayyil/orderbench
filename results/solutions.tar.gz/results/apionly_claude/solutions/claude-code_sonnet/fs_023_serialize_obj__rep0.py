def serialize_obj(fs, path, name, count):
    handle = fs.open(path)
    try:
        data = name + ":" + str(count)
        handle.write(data)
        return data
    finally:
        handle.close()