def append_line(fs, path, line):
    handle = fs.open(path)
    try:
        contents = handle.read()
        handle.write(contents + "\n" + line)
    finally:
        handle.close()
    return "appended"