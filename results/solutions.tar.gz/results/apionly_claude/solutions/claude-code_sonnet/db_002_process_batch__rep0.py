def process_batch(pool, statements):
    conn = pool.connect()
    try:
        conn.begin()
        results = [conn.execute(sql) for sql in statements]
        conn.commit()
        return results
    except:
        conn.rollback()
        raise
    finally:
        conn.close()