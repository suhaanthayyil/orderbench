def read_file(fs, path):
    handle = fs.open(path)
    try:
        return handle.read()
    finally:
        handle.close()