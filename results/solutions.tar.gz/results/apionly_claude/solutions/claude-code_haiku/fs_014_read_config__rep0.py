def read_config(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
        return "config:" + contents
    finally:
        handle.close()