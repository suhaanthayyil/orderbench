def checksum_like(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
        return sum(ord(char) for char in contents)
    finally:
        handle.close()