def transfer_funds(pool, src, dst, amount):
    conn = pool.connect()
    try:
        conn.begin()
        result1 = conn.execute(f"UPDATE accounts SET bal=bal-{amount} WHERE id={src}")
        result2 = conn.execute(f"UPDATE accounts SET bal=bal+{amount} WHERE id={dst}")
        conn.commit()
        return [result1, result2]
    finally:
        conn.close()