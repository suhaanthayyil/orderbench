def conditional_add(env, delta, enabled):
    env.lock.acquire()
    try:
        if enabled:
            result = env.resource.modify(delta)
        else:
            result = env.resource.modify(0)
        return result
    finally:
        env.lock.release()