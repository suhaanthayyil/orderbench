def transform_file(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
        transformed = contents + "!"
        handle.write(transformed)
        return transformed
    finally:
        handle.close()