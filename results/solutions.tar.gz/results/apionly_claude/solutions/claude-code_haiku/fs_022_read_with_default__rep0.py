def read_with_default(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
        return contents
    finally:
        handle.close()