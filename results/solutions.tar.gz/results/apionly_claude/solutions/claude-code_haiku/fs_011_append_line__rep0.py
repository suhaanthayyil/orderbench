def append_line(fs, path, line):
    handle = fs.open(path)
    try:
        contents = handle.read()
        new_contents = contents + '\n' + line
        handle.write(new_contents)
    finally:
        handle.close()
    return "appended"