def serialize_obj(fs, path, name, count):
    serialized = name + ":" + str(count)
    handle = fs.open(path)
    try:
        handle.write(serialized)
    finally:
        handle.close()
    return serialized