def add_then_return(env, amount):
    env.lock.acquire()
    try:
        new_value = env.resource.modify(amount)
        return new_value
    finally:
        env.lock.release()