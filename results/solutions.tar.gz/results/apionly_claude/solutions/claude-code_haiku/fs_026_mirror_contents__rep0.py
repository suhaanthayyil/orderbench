def mirror_contents(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
        handle.write(contents)
        return contents
    finally:
        handle.close()