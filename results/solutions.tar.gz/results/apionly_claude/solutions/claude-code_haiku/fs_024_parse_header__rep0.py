def parse_header(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
        newline_index = contents.find('\n')
        if newline_index == -1:
            return contents
        else:
            return contents[:newline_index]
    finally:
        handle.close()