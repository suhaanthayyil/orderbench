def transfer_between(env, amount):
    env.lock.acquire()
    try:
        env.resource.modify(-amount)
        final_value = env.resource.modify(amount)
        return final_value
    finally:
        env.lock.release()