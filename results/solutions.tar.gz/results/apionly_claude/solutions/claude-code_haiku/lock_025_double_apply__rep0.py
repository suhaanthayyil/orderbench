def double_apply(env, delta):
    env.lock.acquire()
    try:
        env.resource.modify(delta)
        result = env.resource.modify(delta)
        return result
    finally:
        env.lock.release()