def uppercase_file(fs, path):
    handle = fs.open(path)
    try:
        original = handle.read()
        handle.write(original.upper())
        return original
    finally:
        handle.close()