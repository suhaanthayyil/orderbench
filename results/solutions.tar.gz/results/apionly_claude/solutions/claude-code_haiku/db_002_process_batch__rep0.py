def process_batch(pool, statements):
    conn = pool.connect()
    try:
        conn.begin()
        results = []
        for statement in statements:
            result = conn.execute(statement)
            results.append(result)
        conn.commit()
        return results
    finally:
        conn.close()