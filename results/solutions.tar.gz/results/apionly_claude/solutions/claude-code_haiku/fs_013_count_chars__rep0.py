def count_chars(fs, path):
    handle = fs.open(path)
    try:
        contents = handle.read()
        return len(contents)
    finally:
        handle.close()