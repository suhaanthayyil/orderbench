def running_total(env, steps):
    env.lock.acquire()
    try:
        result = 0
        for step in steps:
            result = env.resource.modify(step)
        return result
    finally:
        env.lock.release()