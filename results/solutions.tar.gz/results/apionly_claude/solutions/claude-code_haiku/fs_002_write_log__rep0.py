def write_log(fs, path, message):
    handle = fs.open(path)
    try:
        handle.write(message)
    finally:
        handle.close()
    return "written"