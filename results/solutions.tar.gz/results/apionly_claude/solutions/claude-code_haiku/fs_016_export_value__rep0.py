def export_value(fs, path, value):
    handle = fs.open(path)
    try:
        handle.write(value)
    finally:
        handle.close()
    return "exported"