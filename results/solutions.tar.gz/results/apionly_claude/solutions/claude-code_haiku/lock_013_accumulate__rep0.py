def accumulate(env, step, times):
    env.lock.acquire()
    try:
        result = None
        for _ in range(times):
            result = env.resource.modify(step)
        return result
    finally:
        env.lock.release()